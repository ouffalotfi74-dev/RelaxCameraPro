package com.relax.camerapro;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.Typeface;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    private PreviewView previewView;
    private ImageCapture imageCapture;
    private Camera camera;
    private ProcessCameraProvider cameraProvider;
    private boolean frontCamera = false;
    private boolean flashOn = false;
    private boolean arabic = true;

    private TextView title;
    private Button captureButton, switchButton, flashButton, languageButton;

    private final ActivityResultLauncher<String> permissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) startCamera();
            else Toast.makeText(this, arabic ? "يلزم السماح باستخدام الكاميرا" : "Camera permission is required", Toast.LENGTH_LONG).show();
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildInterface();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA);
        }
    }

    private void buildInterface() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.BLACK);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(18, 12, 18, 12);
        header.setBackgroundColor(Color.rgb(10, 10, 10));

        title = new TextView(this);
        title.setText("RELAX CAMERA PRO");
        title.setTextColor(Color.WHITE);
        title.setTextSize(17);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        languageButton = makeButton("EN");
        languageButton.setOnClickListener(v -> {
            arabic = !arabic;
            updateLabels();
        });
        header.addView(languageButton);
        page.addView(header);

        previewView = new PreviewView(this);
        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        page.addView(previewView, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView hint = new TextView(this);
        hint.setText(arabic ? "التقط لحظتك بأسلوبك" : "Capture the moment your way");
        hint.setTextColor(Color.LTGRAY);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(8, 12, 8, 8);
        page.addView(hint);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(8, 12, 8, 24);
        controls.setBackgroundColor(Color.rgb(10, 10, 10));

        flashButton = makeButton("⚡");
        flashButton.setOnClickListener(v -> {
            flashOn = !flashOn;
            if (imageCapture != null) imageCapture.setFlashMode(flashOn ? ImageCapture.FLASH_MODE_ON : ImageCapture.FLASH_MODE_OFF);
            flashButton.setText(flashOn ? "⚡ ON" : "⚡ OFF");
        });
        controls.addView(flashButton);

        captureButton = makeButton("●");
        captureButton.setTextSize(25);
        captureButton.setTextColor(Color.WHITE);
        captureButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190, 155, 85)));
        LinearLayout.LayoutParams captureParams = new LinearLayout.LayoutParams(82, 68);
        captureParams.setMargins(22, 0, 22, 0);
        controls.addView(captureButton, captureParams);
        captureButton.setOnClickListener(v -> takePhoto());

        switchButton = makeButton("↻");
        switchButton.setOnClickListener(v -> {
            frontCamera = !frontCamera;
            startCamera();
        });
        controls.addView(switchButton);

        page.addView(controls);
        setContentView(page);
        updateLabels();
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(38, 38, 38)));
        return b;
    }

    private void updateLabels() {
        title.setText("RELAX CAMERA PRO");
        languageButton.setText(arabic ? "EN" : "عربي");
        captureButton.setContentDescription(arabic ? "التقاط صورة" : "Take photo");
        switchButton.setContentDescription(arabic ? "تبديل الكاميرا" : "Switch camera");
        flashButton.setContentDescription(arabic ? "الفلاش" : "Flash");
    }

    private void startCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        final var future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                cameraProvider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                imageCapture = new ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setFlashMode(flashOn ? ImageCapture.FLASH_MODE_ON : ImageCapture.FLASH_MODE_OFF)
                    .build();

                CameraSelector selector = frontCamera ? CameraSelector.DEFAULT_FRONT_CAMERA : CameraSelector.DEFAULT_BACK_CAMERA;
                cameraProvider.unbindAll();
                camera = cameraProvider.bindToLifecycle(this, selector, preview, imageCapture);
            } catch (ExecutionException | InterruptedException | IllegalArgumentException e) {
                Toast.makeText(this, arabic ? "تعذر تشغيل الكاميرا" : "Could not start camera", Toast.LENGTH_LONG).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void takePhoto() {
        if (imageCapture == null) return;
        String name = "RELAX_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        values.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
        if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/RelaxCameraPro");

        ImageCapture.OutputFileOptions output = new ImageCapture.OutputFileOptions.Builder(
            getContentResolver(), MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build();

        imageCapture.takePicture(output, ContextCompat.getMainExecutor(this),
            new ImageCapture.OnImageSavedCallback() {
                @Override public void onImageSaved(ImageCapture.OutputFileResults result) {
                    Toast.makeText(MainActivity.this, arabic ? "تم حفظ الصورة في المعرض" : "Photo saved to Gallery", Toast.LENGTH_SHORT).show();
                }
                @Override public void onError(ImageCaptureException error) {
                    Toast.makeText(MainActivity.this, arabic ? "فشل حفظ الصورة" : "Could not save photo", Toast.LENGTH_SHORT).show();
                }
            });
    }
}
